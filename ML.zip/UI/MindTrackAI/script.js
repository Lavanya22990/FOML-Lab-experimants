// State Variables for Simulation
let state = {
    screenTimeHours: 4,
    screenTimeMinutes: 30, // Starting at 4h 30m
    unlockCount: 42,
    socialMediaHours: 2,
    socialMediaMinutes: 15,
    nightUsagePercent: 25,
    score: 0,
    riskLevel: 'Low' // Low, Moderate, High
};

// DOM Elements Mapping
const el = {
    scoreText: document.getElementById('score-text'),
    scoreLabel: document.getElementById('score-label'),
    progressBar: document.getElementById('progress-bar'),
    innerCircle: document.querySelector('.inner-circle'),
    statScreenTime: document.getElementById('stat-screen-time'),
    statUnlocks: document.getElementById('stat-unlocks'),
    statSocial: document.getElementById('stat-social'),
    statNight: document.getElementById('stat-night'),
    insightsList: document.getElementById('insights-list'),
    recommendationsList: document.getElementById('recommendations-list'),
    alertContainer: document.getElementById('alert-container'),
    chatInput: document.getElementById('chat-input'),
    sendBtn: document.getElementById('send-btn'),
    chatMessages: document.getElementById('chatbot-messages'),
    chatHeader: document.getElementById('chatbot-header'),
    chatbot: document.getElementById('chatbot')
};

// Initialize App
function init() {
    calculateScore();
    updateUI();
    initCharts();
    generateInsights();
    generateRecommendations();
    startSimulation();
    initChatbot();
    
    // Initial intro alert
    setTimeout(() => {
        showAlert("MindTrack AI analysis initiated.", "normal");
    }, 1000);
}

// 🧠 Addiction Prediction Logic (Simulated)
function calculateScore() {
    // Formula: (screen_time * 5) + (unlock_count * 0.5) + (night_usage * 2)
    const screenTimeDecimal = state.screenTimeHours + (state.screenTimeMinutes / 60);
    let rawScore = (screenTimeDecimal * 5) + (state.unlockCount * 0.5) + (state.nightUsagePercent * 2); 
    
    // Clamp score to max 100
    state.score = Math.min(Math.round(rawScore), 100);
    
    // Determine risk level based on thresholds
    if (state.score <= 30) {
        state.riskLevel = 'Low';
    } else if (state.score <= 70) {
        state.riskLevel = 'Moderate';
    } else {
        state.riskLevel = 'High';
    }
}

// 🎨 Update UI Elements
function updateUI() {
    // Animate score text
    animateValue(el.scoreText, parseInt(el.scoreText.innerText) || 0, state.score, 1000);
    
    el.scoreLabel.innerText = `Risk Level: ${state.riskLevel}`;
    
    // Update colors based on risk
    let color = 'var(--success)';
    let bgColor = 'rgba(34, 197, 94, 0.1)';
    let glow = 'var(--primary-glow)';

    if (state.riskLevel === 'Moderate') {
        color = 'var(--warning)';
        bgColor = 'rgba(245, 158, 11, 0.1)';
        glow = 'var(--warning-glow)';
    } else if (state.riskLevel === 'High') {
        color = 'var(--danger)';
        bgColor = 'rgba(239, 68, 68, 0.1)';
        glow = 'var(--danger-glow)';
    }
    
    // Apply styles to inner circle
    el.innerCircle.style.color = color;
    el.innerCircle.style.textShadow = `0 0 20px ${glow}`;
    el.scoreLabel.style.color = color;
    el.scoreLabel.style.backgroundColor = bgColor;
    el.scoreLabel.style.borderColor = color;
    
    // Circular Progress Bar Animation
    const degree = (state.score / 100) * 360;
    el.progressBar.style.background = `conic-gradient(${color} ${degree}deg, rgba(255,255,255,0.05) ${degree}deg)`;
    
    // Update Live Stats
    el.statScreenTime.innerText = `${state.screenTimeHours}h ${state.screenTimeMinutes}m`;
    el.statUnlocks.innerText = state.unlockCount;
    el.statSocial.innerText = `${state.socialMediaHours}h ${state.socialMediaMinutes}m`;
    el.statNight.innerText = `${state.nightUsagePercent}%`;
}

// Value Counter Animation
function animateValue(obj, start, end, duration) {
    let startTimestamp = null;
    const step = (timestamp) => {
        if (!startTimestamp) startTimestamp = timestamp;
        const progress = Math.min((timestamp - startTimestamp) / duration, 1);
        obj.innerHTML = Math.floor(progress * (end - start) + start);
        if (progress < 1) {
            window.requestAnimationFrame(step);
        }
    };
    window.requestAnimationFrame(step);
}

// 💡 Generate Dynamic Insights
function generateInsights() {
    const insights = [];
    
    if (state.nightUsagePercent > 20) {
        insights.push({ text: `High usage detected after 11 PM (${state.nightUsagePercent}% of total)`, icon: 'fa-solid fa-moon' });
    }
    if (state.unlockCount > 40) {
        insights.push({ text: `Frequent app switching indicates potential distraction`, icon: 'fa-solid fa-arrows-rotate' });
    }
    if (state.screenTimeHours > 4) {
        insights.push({ text: `Screen time is increasing compared to yesterday`, icon: 'fa-solid fa-arrow-trend-up' });
    }
    
    if (insights.length === 0) {
        insights.push({ text: `Your digital habits look healthy. Keep it up!`, icon: 'fa-solid fa-check-circle' });
    }

    el.insightsList.innerHTML = insights.map(i => `
        <li>
            <i class="${i.icon} text-primary"></i> 
            <span>${i.text}</span>
        </li>
    `).join('');
}

// 🎯 Generate Smart Recommendations
function generateRecommendations() {
    let recs = [];
    if (state.riskLevel === 'High') {
        recs = [
            { text: "Enable Focus Mode immediately", type: "danger", icon: "fa-solid fa-bullseye" },
            { text: "Reduce social media usage", type: "warning", icon: "fa-brands fa-instagram" },
            { text: "Take a 15-minute break now", type: "danger", icon: "fa-solid fa-mug-hot" }
        ];
    } else if (state.riskLevel === 'Moderate') {
        recs = [
            { text: "Reduce late-night usage", type: "warning", icon: "fa-solid fa-moon" },
            { text: "Enable Grayscale mode", type: "normal", icon: "fa-solid fa-droplet-slash" }
        ];
    } else {
        recs = [
            { text: "Keep up the good work!", type: "normal", icon: "fa-solid fa-check" },
            { text: "Review weekly report", type: "normal", icon: "fa-solid fa-chart-line" }
        ];
    }

    el.recommendationsList.innerHTML = recs.map(r => `
        <div class="rec-card ${r.type === 'normal' ? '' : r.type}">
            <i class="${r.icon}"></i>
            <span>${r.text}</span>
        </div>
    `).join('');
}

// 🔄 Simulation Interval (Real-time updates)
function startSimulation() {
    setInterval(() => {
        // Simulate time passing (fast-forwarded)
        state.screenTimeMinutes += 2;
        if (state.screenTimeMinutes >= 60) {
            state.screenTimeHours += 1;
            state.screenTimeMinutes = 0;
            // Alert on new hour threshold
            if(state.screenTimeHours >= 5) {
                showAlert(`⚠️ High usage detected: Over ${state.screenTimeHours} hours today.`, "warning");
            }
        }
        
        // Randomly increase unlocks
        if (Math.random() > 0.6) {
            state.unlockCount += 1;
            if (state.unlockCount % 15 === 0) {
                showAlert("⏳ Take a break. Frequent device checking detected.", "warning");
            }
        }

        // Randomly increase social media time
        if (Math.random() > 0.5) {
            state.socialMediaMinutes += 1;
            if (state.socialMediaMinutes >= 60) {
                state.socialMediaHours += 1;
                state.socialMediaMinutes = 0;
            }
        }
        
        // Slight fluctuation in night usage
        if (Math.random() > 0.8) {
            state.nightUsagePercent = Math.min(100, state.nightUsagePercent + 1);
            if(state.nightUsagePercent === 30) {
                showAlert("💤 Late night usage detected. Consider winding down.", "danger");
            }
        }

        // Recalculate & Update
        calculateScore();
        updateUI();
        generateInsights();
        generateRecommendations();

    }, 4000); // Update every 4 seconds to show live interaction
}

// 🔔 Real-time Alert System
function showAlert(message, type = "normal") {
    const alert = document.createElement('div');
    alert.className = `alert-toast ${type}`;
    
    let icon = "fa-solid fa-info-circle";
    if(type === "warning") icon = "fa-solid fa-triangle-exclamation";
    if(type === "danger") icon = "fa-solid fa-circle-exclamation";

    alert.innerHTML = `
        <i class="${icon}"></i>
        <div>
            <strong>${type.charAt(0).toUpperCase() + type.slice(1)} Alert</strong><br>
            <span style="font-size: 0.9em; opacity: 0.9;">${message}</span>
        </div>
    `;
    
    el.alertContainer.appendChild(alert);

    // Auto-remove after 5 seconds
    setTimeout(() => {
        alert.style.animation = "slideOutRight 0.5s forwards";
        setTimeout(() => alert.remove(), 500);
    }, 5000);
}

// 🤖 Chatbot Logic
function initChatbot() {
    // Toggle Chatbot
    el.chatHeader.addEventListener('click', (e) => {
        if(e.target.closest('.toggle-icon') || e.target.closest('.chatbot-header')) {
            el.chatbot.classList.toggle('collapsed');
            const icon = el.chatHeader.querySelector('.toggle-icon');
            if(el.chatbot.classList.contains('collapsed')) {
                icon.className = 'fa-solid fa-chevron-up toggle-icon';
            } else {
                icon.className = 'fa-solid fa-chevron-down toggle-icon';
                el.chatInput.focus();
            }
        }
    });

    el.sendBtn.addEventListener('click', handleChat);
    el.chatInput.addEventListener('keypress', (e) => {
        if(e.key === 'Enter') handleChat();
    });
}

function handleChat() {
    const text = el.chatInput.value.trim().toLowerCase();
    if (!text) return;

    // Add user message
    appendMessage(text, 'user');
    el.chatInput.value = '';

    // Show typing indicator
    const typingId = appendMessage('<i class="fa-solid fa-ellipsis fa-fade"></i>', 'bot', true);

    // Bot intelligent response logic
    setTimeout(() => {
        // Remove typing indicator
        const typingEl = document.getElementById(typingId);
        if(typingEl) typingEl.remove();

        let response = "I'm not quite sure. Try asking: 'my report', 'am I addicted?', or 'help'.";
        
        if (text.includes('am i addicted') || text.includes('addicted') || text.includes('addiction')) {
            if(state.riskLevel === 'High') {
                response = `Based on your score of ${state.score}, your risk level is High. I strongly suggest enabling Focus Mode and taking a screen break immediately.`;
            } else if(state.riskLevel === 'Moderate') {
                response = `Your score is ${state.score} (Moderate). You're doing okay, but you might want to watch your social media usage.`;
            } else {
                response = `Your score is ${state.score} (Low). You have healthy digital habits!`;
            }
        } 
        else if (text.includes('reduce') || text.includes('help') || text.includes('suggestions') || text.includes('how to')) {
            response = `Here are some proven ways to reduce usage:<br><br>
            1. Enable Grayscale mode on your phone<br>
            2. Put your phone in another room while working<br>
            3. Use the 20-20-20 rule for your eyes<br>
            4. Turn off all non-essential notifications.`;
        }
        else if (text.includes('report') || text.includes('summary') || text.includes('stats')) {
            response = `📊 <b>Your Live Report:</b><br><br>
            • Screen Time: ${state.screenTimeHours}h ${state.screenTimeMinutes}m<br>
            • Device Unlocks: ${state.unlockCount}<br>
            • Social Media: ${state.socialMediaHours}h ${state.socialMediaMinutes}m<br>
            • Risk Score: ${state.score}/100 (${state.riskLevel})`;
        }

        appendMessage(response, 'bot');
    }, 1000 + Math.random() * 500); // Simulated network delay
}

function appendMessage(text, sender, isHTML = false) {
    const msg = document.createElement('div');
    const id = 'msg-' + Date.now();
    msg.id = id;
    msg.className = `message ${sender}-message`;
    
    if(isHTML || sender === 'bot') {
        msg.innerHTML = text; // Allow HTML for bot formatting
    } else {
        msg.innerText = text;
    }
    
    el.chatMessages.appendChild(msg);
    el.chatMessages.scrollTop = el.chatMessages.scrollHeight;
    return id;
}

// 📈 Chart.js Data Visualization Setup
function initCharts() {
    Chart.defaults.color = '#94a3b8';
    Chart.defaults.font.family = "'Inter', sans-serif";
    Chart.defaults.scale.grid.color = 'rgba(255,255,255,0.05)';

    // Line Chart - Screen Time Trend
    const lineCtx = document.getElementById('lineChart').getContext('2d');
    
    // Create gradient for line chart
    let gradient = lineCtx.createLinearGradient(0, 0, 0, 300);
    gradient.addColorStop(0, 'rgba(34, 197, 94, 0.5)');
    gradient.addColorStop(1, 'rgba(34, 197, 94, 0.0)');

    new Chart(lineCtx, {
        type: 'line',
        data: {
            labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Today'],
            datasets: [{
                label: 'Screen Time (Hours)',
                data: [3.5, 4.2, 5.1, 4.8, 6.5, 7.2, 4.5],
                borderColor: '#22c55e',
                backgroundColor: gradient,
                borderWidth: 3,
                fill: true,
                tension: 0.4,
                pointBackgroundColor: '#020617',
                pointBorderColor: '#22c55e',
                pointBorderWidth: 3,
                pointRadius: 4,
                pointHoverRadius: 6
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    backgroundColor: 'rgba(15, 23, 42, 0.9)',
                    titleFont: { family: 'Inter', size: 13 },
                    bodyFont: { family: 'Inter', size: 14, weight: 'bold' },
                    padding: 12,
                    cornerRadius: 8,
                    displayColors: false
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    border: { display: false }
                },
                x: {
                    grid: { display: false },
                    border: { display: false }
                }
            }
        }
    });

    // Bar Chart - App Usage
    const barCtx = document.getElementById('barChart').getContext('2d');
    new Chart(barCtx, {
        type: 'bar',
        data: {
            labels: ['Instagram', 'YouTube', 'WhatsApp', 'Twitter', 'TikTok'],
            datasets: [{
                label: 'Usage (Hours)',
                data: [2.5, 1.8, 1.2, 0.8, 1.5],
                backgroundColor: [
                    'rgba(239, 68, 68, 0.8)',  // Danger/Red
                    'rgba(245, 158, 11, 0.8)', // Warning/Orange
                    'rgba(34, 197, 94, 0.8)',  // Success/Green
                    'rgba(56, 189, 248, 0.8)', // Info/Blue
                    'rgba(168, 85, 247, 0.8)'  // Purple
                ],
                borderRadius: 6,
                borderSkipped: false
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: { display: false },
                tooltip: {
                    backgroundColor: 'rgba(15, 23, 42, 0.9)',
                    padding: 12,
                    cornerRadius: 8
                }
            },
            scales: {
                y: {
                    beginAtZero: true,
                    border: { display: false }
                },
                x: {
                    grid: { display: false },
                    border: { display: false }
                }
            }
        }
    });
}

// Start Application
document.addEventListener('DOMContentLoaded', init);
